// Serverless function for Vercel.
// The variance maths is done HERE in code, not by the AI.
// Claude only writes the commentary, using the rules in skill/SKILL.md.

const fs = require("fs");
const path = require("path");

const MAX_LINES = 30;

function loadSkill() {
  try {
    return fs.readFileSync(path.join(process.cwd(), "skill", "SKILL.md"), "utf8");
  } catch (e) {
    return "Write a short, factual commentary on budget variances. Use only the numbers given. Never state causes as fact.";
  }
}

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

function validate(body) {
  if (!body || !Array.isArray(body.lines) || body.lines.length < 1 || body.lines.length > MAX_LINES) {
    return "Enter between 1 and " + MAX_LINES + " line items.";
  }
  const threshold = Number(body.threshold);
  if (!Number.isFinite(threshold) || threshold < 0 || threshold > 100) {
    return "Threshold must be a number between 0 and 100.";
  }
  for (const l of body.lines) {
    if (typeof l.name !== "string" || l.name.trim() === "" || l.name.length > 60) {
      return "Every line needs a name (up to 60 characters).";
    }
    if (l.type !== "revenue" && l.type !== "expense") {
      return "Type must be revenue or expense.";
    }
    const b = Number(l.budget);
    const a = Number(l.actual);
    if (l.budget === "" || l.actual === "" || !Number.isFinite(b) || !Number.isFinite(a) || b < 0 || a < 0) {
      return "Budget and actual must be numbers of zero or more (line: " + l.name + ").";
    }
  }
  return null;
}

function analyse(lines, threshold) {
  const rows = lines.map((l) => {
    const budget = Number(l.budget);
    const actual = Number(l.actual);
    const variance = actual - budget;
    const pct = budget === 0 ? null : (variance / budget) * 100;
    let result = "On budget";
    if (variance !== 0) {
      const favourable = l.type === "revenue" ? variance > 0 : variance < 0;
      result = favourable ? "Favourable" : "Adverse";
    }
    const flagged = variance !== 0 && (pct === null || Math.abs(pct) > threshold);
    return {
      name: l.name.trim(),
      type: l.type,
      budget: round2(budget),
      actual: round2(actual),
      variance: round2(variance),
      variancePct: pct === null ? null : round2(pct),
      result,
      flagged,
    };
  });

  const sum = (type, key) => rows.filter((r) => r.type === type).reduce((a, r) => a + r[key], 0);
  const budgetNet = sum("revenue", "budget") - sum("expense", "budget");
  const actualNet = sum("revenue", "actual") - sum("expense", "actual");
  const netVariance = actualNet - budgetNet;
  const totals = {
    revenueBudget: round2(sum("revenue", "budget")),
    revenueActual: round2(sum("revenue", "actual")),
    expenseBudget: round2(sum("expense", "budget")),
    expenseActual: round2(sum("expense", "actual")),
    netBudget: round2(budgetNet),
    netActual: round2(actualNet),
    netVariance: round2(netVariance),
    netVariancePct: budgetNet === 0 ? null : round2((netVariance / Math.abs(budgetNet)) * 100),
    netResult: netVariance === 0 ? "On budget" : netVariance > 0 ? "Favourable" : "Adverse",
  };
  return { rows, totals };
}

async function getCommentary(rows, totals, threshold) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY is not set on the server.");
  const model = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";

  const userMessage =
    "Review threshold: " + threshold + "%. Currency: Indian rupees.\n" +
    "These results are already calculated. Do not recalculate or change any number.\n\n" +
    JSON.stringify({ lines: rows, totals }, null, 2) +
    "\n\nWrite the commentary now, following the skill instructions.";

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: 700,
      system: loadSkill() + "\n\nReply in plain text only.",
      messages: [{ role: "user", content: userMessage }],
    }),
  });
  const data = await resp.json();
  if (!resp.ok) {
    throw new Error((data && data.error && data.error.message) || "Claude API request failed.");
  }
  return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
}

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Use POST." });
    return;
  }
  const error = validate(req.body);
  if (error) {
    res.status(400).json({ error });
    return;
  }
  const threshold = Number(req.body.threshold);
  const { rows, totals } = analyse(req.body.lines, threshold);
  try {
    const commentary = await getCommentary(rows, totals, threshold);
    res.status(200).json({ rows, totals, threshold, commentary });
  } catch (e) {
    // The table stays correct even if the AI commentary fails.
    res.status(200).json({ rows, totals, threshold, commentary: null, commentaryError: e.message });
  }
};

module.exports.analyse = analyse;
module.exports.validate = validate;
